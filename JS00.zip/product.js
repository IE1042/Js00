var num1 = 15;
var num2 = 10;
var num3 = 5;
var result = num1 * num2 * num3;
console.log(result);