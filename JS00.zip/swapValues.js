var a = 10;
var b = 20;

var temp = a;
a = b;
b = temp;

console.log("a:", a);
console.log("b:", b);
